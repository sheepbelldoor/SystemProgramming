/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_431()
{
    return 2425393752U;
}

void setval_309(unsigned *p)
{
    *p = 3284633932U;
}

unsigned getval_328()
{
    return 3281031248U;
}

unsigned getval_190()
{
    return 1925404836U;
}

void setval_115(unsigned *p)
{
    *p = 2428995904U;
}

unsigned getval_356()
{
    return 3284633928U;
}

unsigned addval_456(unsigned x)
{
    return x + 3284633928U;
}

unsigned getval_429()
{
    return 3281031256U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned addval_395(unsigned x)
{
    return x + 2447411528U;
}

unsigned getval_138()
{
    return 3264272009U;
}

unsigned getval_276()
{
    return 3683964553U;
}

unsigned addval_254(unsigned x)
{
    return x + 2429979623U;
}

unsigned addval_376(unsigned x)
{
    return x + 3286272328U;
}

unsigned addval_421(unsigned x)
{
    return x + 3281111689U;
}

unsigned addval_364(unsigned x)
{
    return x + 2430634440U;
}

unsigned getval_174()
{
    return 3224950281U;
}

unsigned getval_248()
{
    return 3380923017U;
}

unsigned getval_246()
{
    return 3526412937U;
}

unsigned getval_145()
{
    return 3223896457U;
}

void setval_347(unsigned *p)
{
    *p = 3249079564U;
}

void setval_240(unsigned *p)
{
    *p = 3767093693U;
}

unsigned getval_499()
{
    return 2497743176U;
}

unsigned getval_397()
{
    return 3682912937U;
}

void setval_172(unsigned *p)
{
    *p = 2464188744U;
}

void setval_114(unsigned *p)
{
    *p = 3223372161U;
}

void setval_255(unsigned *p)
{
    *p = 3676359305U;
}

unsigned addval_144(unsigned x)
{
    return x + 3246997289U;
}

unsigned addval_443(unsigned x)
{
    return x + 2428602836U;
}

unsigned getval_263()
{
    return 3536112265U;
}

unsigned addval_159(unsigned x)
{
    return x + 3678983817U;
}

unsigned addval_104(unsigned x)
{
    return x + 3281174921U;
}

void setval_454(unsigned *p)
{
    *p = 2445379949U;
}

unsigned getval_202()
{
    return 4123252361U;
}

unsigned addval_339(unsigned x)
{
    return x + 2425670281U;
}

unsigned getval_467()
{
    return 3375421065U;
}

void setval_485(unsigned *p)
{
    *p = 3286288712U;
}

unsigned getval_143()
{
    return 2430634312U;
}

void setval_288(unsigned *p)
{
    *p = 3531921033U;
}

unsigned addval_116(unsigned x)
{
    return x + 3281043851U;
}

unsigned addval_186(unsigned x)
{
    return x + 3529558665U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
